Example 10: scrolling_menu
==================

![schematic](https://github.com/VasilKalchev/LiquidMenu/blob/master/examples/J_scrolling_menu/scrolling_menu.png?raw=true)
This example demonstrates how to use scrolling lines and how to overwrite the default number of displayed decimal places.