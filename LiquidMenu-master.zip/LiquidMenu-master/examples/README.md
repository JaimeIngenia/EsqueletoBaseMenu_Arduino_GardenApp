![example](https://raw.githubusercontent.com/VaSe7u/LiquidMenu/master/doc/img/sch/examples.gif)
