Example 6: focus_menu
==================

![schematic](https://github.com/VasilKalchev/LiquidMenu/blob/master/examples/F_focus_menu/focus_menu.png?raw=true)
This example demonstrates how to customize the focus indicator.
