Example 11: getters_menu
==================

![schematic](https://github.com/VasilKalchev/LiquidMenu/blob/master/examples/K_getters_menu/getters_menu.png?raw=true)
This example demonastrates how to use getter functions instead of variables in "LiquidScreen" objects.
